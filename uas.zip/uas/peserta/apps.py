from django.apps import AppConfig


class PesertaConfig(AppConfig):
    name = 'peserta'
