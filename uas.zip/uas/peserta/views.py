from django.shortcuts import render

from .models import Participant


def index(request):

    postingan = Participant.objects.all()

    context = {
        'TampungPostingan': postingan,

    }

    return render(request, 'peserta/index.html', context)
