from django.contrib import admin

from .models import Participant, Certification


admin.site.register(Participant)
admin.site.register(Certification)
