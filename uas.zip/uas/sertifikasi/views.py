from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

from .models import Certification


def index(request):

    postingan = Certification.objects.all()

    context = {
        'TampungPostingan': postingan,

    }

    return render(request, 'sertifikasi/index.html', context)
