from django.apps import AppConfig


class SertifikasiConfig(AppConfig):
    name = 'sertifikasi'
